/* Mobile Zone front-end cart and order-request checkout.
   IMPORTANT: This is a static website. It does not process online payments.
   Set SHOP_WHATSAPP to the shop number in international format, digits only.
   Example Pakistan: 923001234567 (do not include +, spaces, or leading 0).
*/
const SHOP_WHATSAPP = "923001234567"; // REPLACE with your real WhatsApp number
const products = Array.isArray(window.MOBILE_ZONE_PRODUCTS) ? window.MOBILE_ZONE_PRODUCTS : [];
const money = value => new Intl.NumberFormat("en-PK", {style:"currency",currency:"PKR",maximumFractionDigits:0}).format(value).replace("PKR","PKR");
const byId = id => document.getElementById(id);
let activeCategory = "All";
let cart = JSON.parse(sessionStorage.getItem("mobileZoneCart") || "[]");
let toastTimer;

const productGrid = byId("productGrid");
const searchInput = byId("searchInput");
const sortSelect = byId("sortSelect");
const overlay = byId("overlay");
const cartDrawer = byId("cartDrawer");
const checkoutModal = byId("checkoutModal");

function safeText(value){return String(value ?? "").replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));}
function productById(id){return products.find(p => p.id === id);}
function saveCart(){sessionStorage.setItem("mobileZoneCart",JSON.stringify(cart));}
function showToast(message){const el=byId("toast");el.textContent=message;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),2300);}
function productImage(product){return product.image || "assets/product-placeholder.svg";}

function renderProducts(){
  let list = products.filter(p => (activeCategory==="All" || p.category===activeCategory || (activeCategory==="Accessories" && p.category!=="Phones")) &&
    (p.name+" "+p.category+" "+(p.description||"")).toLowerCase().includes(searchInput.value.trim().toLowerCase()));
  if(sortSelect.value==="low") list.sort((a,b)=>a.price-b.price);
  if(sortSelect.value==="high") list.sort((a,b)=>b.price-a.price);
  if(sortSelect.value==="name") list.sort((a,b)=>a.name.localeCompare(b.name));
  byId("productCount").textContent = `${list.length} ${list.length===1?"product":"products"}`;
  byId("emptyState").classList.toggle("hidden",list.length!==0);
  productGrid.innerHTML = list.map(p=>`<article class="product-card">
    <div class="product-visual"><img loading="lazy" src="${safeText(productImage(p))}" alt="${safeText(p.name)}" onerror="this.onerror=null;this.src='assets/product-placeholder.svg'">
    ${p.label?`<span class="product-label">${safeText(p.label)}</span>`:""}
    <button class="quick-add" data-add="${safeText(p.id)}" aria-label="Add ${safeText(p.name)} to bag">+</button></div>
    <div class="product-info"><p class="product-category">${safeText(p.category)}</p><h3 class="product-name">${safeText(p.name)}</h3>
    <p class="product-description">${safeText(p.description||"Contact us for product details.")}</p>
    <div class="product-price">${money(Number(p.price)||0)}${p.oldPrice?` <del>${money(Number(p.oldPrice))}</del>`:""}</div></div></article>`).join("");
}
function addToCart(id){const p=productById(id);if(!p)return;const row=cart.find(i=>i.id===id);if(row)row.qty++;else cart.push({id,qty:1});saveCart();renderCart();showToast(`${p.name} added to your bag`);}
function changeQty(id,delta){const row=cart.find(i=>i.id===id);if(!row)return;row.qty+=delta;if(row.qty<=0)cart=cart.filter(i=>i.id!==id);saveCart();renderCart();}
function removeItem(id){cart=cart.filter(i=>i.id!==id);saveCart();renderCart();}
function cartQty(){return cart.reduce((n,i)=>n+i.qty,0);}
function cartTotal(){return cart.reduce((sum,i)=>{const p=productById(i.id);return sum+(p?Number(p.price)*i.qty:0)},0);}
function renderCart(){
  cart=cart.filter(i=>productById(i.id));saveCart();
  byId("cartCount").textContent=cartQty();byId("drawerCount").textContent=`(${cartQty()})`;
  byId("cartItems").innerHTML=cart.map(i=>{const p=productById(i.id);return `<div class="cart-line">
    <img class="cart-thumb" src="${safeText(productImage(p))}" alt="" onerror="this.onerror=null;this.src='assets/product-placeholder.svg'">
    <div><h4>${safeText(p.name)}</h4><small>${money(p.price)} each</small><div class="quantity-control"><button data-qty="${safeText(p.id)}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${i.qty}</span><button data-qty="${safeText(p.id)}" data-delta="1" aria-label="Increase quantity">+</button></div><button class="remove-item" data-remove="${safeText(p.id)}">Remove</button></div>
    <strong class="cart-line-total">${money(p.price*i.qty)}</strong></div>`}).join("");
  byId("cartEmpty").classList.toggle("hidden",cart.length>0);byId("cartFooter").classList.toggle("hidden",cart.length===0);
  byId("cartSubtotal").textContent=money(cartTotal());byId("checkoutItems").textContent=cartQty();byId("checkoutSubtotal").textContent=money(cartTotal());
}
function openCart(){closeCheckout();overlay.classList.add("open");cartDrawer.classList.add("open");cartDrawer.setAttribute("aria-hidden","false");document.body.style.overflow="hidden";}
function closeCart(){cartDrawer.classList.remove("open");cartDrawer.setAttribute("aria-hidden","true");if(!checkoutModal.classList.contains("open")){overlay.classList.remove("open");document.body.style.overflow="";}}
function openCheckout(){if(!cart.length){showToast("Add a product to your bag first.");return;}cartDrawer.classList.remove("open");cartDrawer.setAttribute("aria-hidden","true");checkoutModal.classList.add("open");checkoutModal.setAttribute("aria-hidden","false");overlay.classList.add("open");document.body.style.overflow="hidden";byId("customerName").focus();}
function closeCheckout(){checkoutModal.classList.remove("open");checkoutModal.setAttribute("aria-hidden","true");if(!cartDrawer.classList.contains("open")){overlay.classList.remove("open");document.body.style.overflow="";}}
function setCategory(category){activeCategory=category;document.querySelectorAll(".category-tab").forEach(b=>b.classList.toggle("active",b.dataset.category===category));renderProducts();}
function orderMessage(form){
 const lines=cart.map(i=>{const p=productById(i.id);return `• ${p.name} x${i.qty} — ${money(p.price*i.qty)}`;}).join("\n");
 return `Hello Mobile Zone, I would like to place an order request:\n\n${lines}\n\nSubtotal: ${money(cartTotal())}\n\nName: ${form.customerName}\nPhone: ${form.customerPhone}\nAddress: ${form.customerAddress}\nPreferred payment: ${form.paymentMethod}\n\nPlease confirm availability, delivery charges and payment details.`;
}
productGrid.addEventListener("click",e=>{const btn=e.target.closest("[data-add]");if(btn)addToCart(btn.dataset.add);});
byId("cartItems").addEventListener("click",e=>{const qty=e.target.closest("[data-qty]");const rem=e.target.closest("[data-remove]");if(qty)changeQty(qty.dataset.qty,Number(qty.dataset.delta));if(rem)removeItem(rem.dataset.remove);});
byId("categoryTabs").addEventListener("click",e=>{const b=e.target.closest("[data-category]");if(b)setCategory(b.dataset.category);});
document.querySelectorAll("[data-nav-category]").forEach(a=>a.addEventListener("click",()=>setCategory(a.dataset.navCategory==="Accessories"?"Accessories":a.dataset.navCategory)));
document.querySelectorAll("[data-banner-category]").forEach(a=>a.addEventListener("click",()=>setCategory("Accessories")));
searchInput.addEventListener("input",renderProducts);sortSelect.addEventListener("change",renderProducts);
byId("searchToggle").addEventListener("click",()=>{byId("searchBox").scrollIntoView({behavior:"smooth",block:"center"});setTimeout(()=>searchInput.focus(),250);});
byId("openCart").addEventListener("click",openCart);byId("closeCart").addEventListener("click",closeCart);byId("continueShopping").addEventListener("click",closeCart);
byId("checkoutButton").addEventListener("click",openCheckout);byId("closeCheckout").addEventListener("click",closeCheckout);
overlay.addEventListener("click",()=>{closeCart();closeCheckout();});
byId("resetFilters").addEventListener("click",()=>{searchInput.value="";sortSelect.value="featured";setCategory("All");});
byId("paymentMethod").addEventListener("change",e=>{byId("paymentWarning").classList.toggle("hidden",!e.target.value.startsWith("Online"));});
byId("checkoutForm").addEventListener("submit",e=>{
 e.preventDefault();if(!cart.length){closeCheckout();showToast("Your bag is empty.");return;}
 const form=Object.fromEntries(new FormData(e.currentTarget).entries());
 if(form.paymentMethod.startsWith("Online")){byId("formError").textContent="Online payment is not configured. Choose another method, or contact the shop to arrange payment.";byId("formError").classList.remove("hidden");return;}
 byId("formError").classList.add("hidden");
 const message=orderMessage(form);
 if(!/^\d{10,15}$/.test(SHOP_WHATSAPP)){byId("formError").textContent="Please set SHOP_WHATSAPP in script.js to your shop's WhatsApp number (country code + number, digits only) before accepting orders.";byId("formError").classList.remove("hidden");return;}
 const url=`https://wa.me/${SHOP_WHATSAPP}?text=${encodeURIComponent(message)}`;
 window.open(url,"_blank","noopener,noreferrer");
 cart=[];saveCart();renderCart();e.currentTarget.reset();closeCheckout();showToast("Order message prepared in WhatsApp.");
});
document.addEventListener("keydown",e=>{if(e.key==="Escape"){closeCart();closeCheckout();}});
byId("year").textContent=new Date().getFullYear();
renderProducts();renderCart();
