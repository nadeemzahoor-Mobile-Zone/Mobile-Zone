/*
  MOBILE ZONE INVENTORY
  Edit this file to add, remove or update products.
  price and oldPrice are numbers in PKR (no commas).
  category must match a category button in index.html:
  Phones, Covers, Charging, Audio, Power, Wearables, Protection
  image can be a relative file path (e.g. "assets/my-phone.jpg") or an image URL.
  Keep image URLs you have permission to use.
*/
window.MOBILE_ZONE_PRODUCTS = [
  {id:"phone-001",name:"Everyday Smartphone",category:"Phones",price:64999,oldPrice:69999,label:"Popular",description:"128GB storage · Dual camera · 4G/5G",image:"https://images.unsplash.com/photo-1598327105666-5b89351aff97?auto=format&fit=crop&w=700&q=80"},
  {id:"phone-002",name:"Premium Smartphone",category:"Phones",price:139999,oldPrice:null,label:"Premium",description:"256GB storage · High-resolution display",image:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?auto=format&fit=crop&w=700&q=80"},
  {id:"cover-001",name:"Minimal Phone Cover",category:"Covers",price:899,oldPrice:null,label:"Everyday",description:"Slim profile · Comfortable grip",image:"https://images.unsplash.com/photo-1601593346740-925612772716?auto=format&fit=crop&w=700&q=80"},
  {id:"charge-001",name:"Fast Wall Charger",category:"Charging",price:2499,oldPrice:null,label:"Essential",description:"Compact charging adapter · USB compatible",image:"https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=700&q=80"},
  {id:"charge-002",name:"USB-C Charging Cable",category:"Charging",price:799,oldPrice:null,label:"Essential",description:"Durable cable for everyday charging",image:"https://images.unsplash.com/photo-1615526675159-e248c3021d3f?auto=format&fit=crop&w=700&q=80"},
  {id:"audio-001",name:"Wireless Earbuds",category:"Audio",price:5999,oldPrice:6999,label:"Popular",description:"Wireless listening · Charging case",image:"https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?auto=format&fit=crop&w=700&q=80"},
  {id:"power-001",name:"Portable Power Bank",category:"Power",price:4499,oldPrice:null,label:"On the go",description:"Portable backup power · LED indicators",image:"https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?auto=format&fit=crop&w=700&q=80"},
  {id:"wear-001",name:"Smartwatch",category:"Wearables",price:8999,oldPrice:null,label:"Featured",description:"Fitness tracking · Notifications",image:"https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=700&q=80"},
  {id:"protect-001",name:"Tempered Glass Protector",category:"Protection",price:499,oldPrice:null,label:"Protection",description:"Screen protection · Clear finish",image:"https://images.unsplash.com/photo-1512499617640-c74ae3a79d37?auto=format&fit=crop&w=700&q=80"}
];
