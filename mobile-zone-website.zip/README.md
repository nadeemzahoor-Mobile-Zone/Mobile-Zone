# Mobile Zone — Phones & Accessories

A responsive, black-and-white storefront for GitHub Pages. It includes product search, category filters, sorting, a cart, and a checkout form that prepares an order request in WhatsApp.

## Files

- `index.html` — storefront markup
- `styles.css` — responsive styling
- `products.js` — **edit this file to manage products and prices**
- `script.js` — cart and checkout behavior; set your WhatsApp number here
- `assets/product-placeholder.svg` — fallback product image

## Before publishing

1. Open `script.js`.
2. Replace `923001234567` in `SHOP_WHATSAPP` with your shop's WhatsApp number in international format, digits only. Example format: `923001234567` for a Pakistani number. Do not use `+`, spaces, or the leading local `0`.
3. Open `products.js` and replace sample products, prices, descriptions and image paths/URLs with your actual stock.
4. Check that each product has a unique `id`, a numeric `price` in PKR, and a category from: `Phones`, `Covers`, `Charging`, `Audio`, `Power`, `Wearables`, `Protection`.
5. Test the site on desktop and mobile. Place a test order and confirm the WhatsApp message is correct before sharing the site.

### Add a product

Add another object inside `window.MOBILE_ZONE_PRODUCTS` in `products.js`:

```js
{
  id: "cover-002",
  name: "Clear Phone Cover",
  category: "Covers",
  price: 1200,
  oldPrice: null,
  label: "New",
  description: "Clear, slim-fit protective cover",
  image: "assets/clear-cover.jpg"
}
```

For local product photos, upload the image into `assets/` and set `image` to its relative path, such as `assets/clear-cover.jpg`. Use photos you own or have permission to use. Prices are in PKR and should be numbers without commas.

## Publish with GitHub Pages

1. Sign in at https://github.com and create a repository named `mobile-zone` (a public repository is the simplest choice for GitHub Free Pages).
2. Upload the contents of this folder to the **root** of the repository. Ensure `index.html` is at the repository root, not nested inside another `mobile-zone-website` folder.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select branch `main` and folder `/(root)`, then click **Save**.
6. Wait for the Pages deployment to finish. The URL will usually look like `https://YOUR-USERNAME.github.io/mobile-zone/`. Open **Settings → Pages** to see the actual URL.
7. Every time you update and commit the files, GitHub Pages republishes the site.

Official guide: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Important: online payment and backend

GitHub Pages serves static files only. This project does **not** charge cards, process wallet payments, store orders in a secure database, calculate delivery, or confirm inventory. The current checkout creates a message and opens WhatsApp; the shop must confirm the order and payment manually. The online-payment option is intentionally blocked.

To offer true online checkout, add a trusted payment provider that supports your registered business and customers' payment methods, plus a secure server-side backend (or a hosted e-commerce platform). The backend must create payment sessions/orders, keep secret API keys off the website, verify payment status using signed webhooks, and only then mark orders paid. Never put private API keys in `script.js` or any public GitHub repository.

For a Pakistan-based shop, contact local providers/acquirers such as your bank and providers that offer merchant onboarding in Pakistan, and confirm their current eligibility, fees, settlement, refund and webhook documentation directly with them. Do not assume Stripe is available for a Pakistan-registered business; check the official country availability before choosing any gateway.

For a starter shop, WhatsApp order requests and cash-on-delivery confirmation are the simplest setup. For card/wallet payments, use a hosted checkout from a provider that approves your business, or a full e-commerce platform with a supported Pakistan payment integration.

## Security / privacy notes

- This static website does not save customer details to a database. Customer information is placed in a WhatsApp message only after the customer submits the form.
- GitHub Pages sites are public on the internet. Do not upload private customer data, passwords, API secrets, or payment keys.
- Sample prices and product listings are placeholders; replace them before launch.
